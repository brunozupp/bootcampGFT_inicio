package br.com.novelitech.exemplo.maven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetotesteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetotesteApplication.class, args);
	}

}
