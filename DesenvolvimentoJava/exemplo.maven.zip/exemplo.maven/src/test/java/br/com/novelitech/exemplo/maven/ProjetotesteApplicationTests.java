package br.com.novelitech.exemplo.maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetotesteApplicationTests {

	@Test
	void contextLoads() {
	}

}
